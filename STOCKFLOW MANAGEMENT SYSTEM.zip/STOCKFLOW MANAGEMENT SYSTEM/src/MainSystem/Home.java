/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package MainSystem;

import Utilities.AddInventory;
import Main.Main;
import PopUp_Messages.Logout_pop_up;
import java.awt.Color;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import javax.swing.DefaultComboBoxModel;
import javax.swing.table.DefaultTableModel;
import java.util.ArrayList;
/**
 *
 * @author crissa jean pagapong
 */
public class Home extends javax.swing.JFrame {
    private Connection conn = Database.Db_conn.conn();
    private DefaultTableModel invTable = new DefaultTableModel(new String[]{"ID", "Product Name", "Purch. Price", "Sales Value", "Available Stock"}, 0);
    private DefaultComboBoxModel filter = new DefaultComboBoxModel(new String[]{"All", "Electronics", "Housekeeping", "Sports and Fitness", "Kitchen Applicances", "Utility", "Miscellaneous"});
    private DecimalFormat toDecimal = new DecimalFormat("#,###.00");
    
    private String adminID;
    private boolean isSearching = false;
    private boolean isSessionSaved = false;
    private String searchFilter = "";
    private String searchFilterCategory = "All";
    private ArrayList<String>itemsCategory = new ArrayList<String>(); 
    /**
     * Creates new form HOME 
     */
    public Home(String id, boolean isSessionSaved) {
        adminID = id;
        this.isSessionSaved = isSessionSaved;
        initComponents();
        
        inventoryTable.setModel(invTable);
        categoryFilter.setModel(filter);
        setInventoryTable();
        setLogistics();
    }

    public Home() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    public void setInventoryTable(){
        String query;
        
        if(isSearching){
            if(searchFilterCategory.equalsIgnoreCase("All")){
                query = "SELECT * FROM inventory WHERE Product_Name LIKE '%"+searchFilter+"%';";
            }else{
                query = "SELECT * FROM inventory WHERE Product_Name LIKE '%"+searchFilter+"%' AND Product_Category = '"+searchFilterCategory+"';";
            }
        }else if(searchFilterCategory.equalsIgnoreCase("All")){
            query = "SELECT * FROM inventory;";
        }else{
            query = "SELECT * FROM inventory WHERE Product_Category = '"+searchFilterCategory+"';";
        }
        
        int invTableRow = 0;
        invTable.setRowCount(invTableRow);
        
        try{
            PreparedStatement pst = conn.prepareStatement(query);
            ResultSet rs = pst.executeQuery();
            
            while(rs.next()){
                invTableRow++;
                itemsCategory.add(rs.getString(3));
                invTable.setRowCount(invTableRow);
                invTable.setValueAt(rs.getString(1), invTableRow-1, 0);
                invTable.setValueAt(rs.getString(2), invTableRow-1, 1);
                invTable.setValueAt(toDecimal.format(Double.parseDouble(rs.getString(4))), invTableRow-1, 2);
                invTable.setValueAt(toDecimal.format(Double.parseDouble(rs.getString(5))), invTableRow-1, 3);
                invTable.setValueAt(rs.getString(6), invTableRow-1, 4);
            }
        }catch(Exception err){
            System.out.println(err);
        }
    }
    
    public void resetNavigator(){
        homeNavigator.setBorder(null);
        inventoryNavigator.setBorder(null);
        logisticNavigator.setBorder(null);
    }

    public void setLogistics(){
        // Set Current Stock, Stock Value, and Average Purchase Price
        try{
            String query = "SELECT logistics.Quantity, logistics.Amount FROM logistics WHERE Order_Type = 'Purchase';";
            int currentStockQ = 0;
            double stockValueQ = 0;
            int divider = 0;
            double maxPurchase = 0;
            
            // Prepare the query for execution.
            PreparedStatement pst = conn.prepareStatement(query);
            
            /* Get Result set.
               ____________________
               | Quantity | Amount | 
            */
            ResultSet rs = pst.executeQuery();
            
            // While there is a result continue the Loop otherwise stop.
            while(rs.next()){
                currentStockQ += rs.getInt(1);
                double purchase = rs.getDouble(2);
                stockValueQ += purchase;
                
                // Set maxPurchase if the purchase is greater than maxPurchase.
                if(purchase > maxPurchase) maxPurchase = purchase;
                divider++; // for Later use (getting the average).
            }
        
        
            // Convert value to string before setting it to currentStock.
            currentStock.setText(String.valueOf(currentStockQ));
            
            // Format value before setting it to their curresponding jLabel for more readability.
            double averagePurchaseTemp = stockValueQ/divider;
            stockValue .setText(toDecimal.format(stockValueQ));
            avgPurchase.setText(toDecimal.format(averagePurchaseTemp));
            maxPurchaseS.setText(toDecimal.format(maxPurchase));
        
            // Formula for getting the percentage
            double percent = averagePurchaseTemp/maxPurchase*100;
        
            // Parse to String and split the decimals, to the value to set t avgPurchase wont contain a decimal otherwise error occurs.
            // Escape "." character;
            String percentString[] = String.valueOf(percent).split("\\.");

            // Get the from percentInt at index 0 and parse to Int.
            avgPurchasePrice.setValue(Integer.parseInt(percentString[0]));
        }catch(Exception err){
            System.out.println(err);
        }
        
        // Set Average Sale Price
        try{
            String query = "SELECT logistics.Quantity, logistics.Amount FROM logistics WHERE Order_Type = 'Sale';";
            double saleValueQ = 0;
            int divider = 0;
            double maxSale = 0;
            
            // Prepare the query for execution.
            PreparedStatement pst = conn.prepareStatement(query);
            
            /* Get Result set.
               ____________________
               | Quantity | Amount | 
            */
            ResultSet rs = pst.executeQuery();
            
            // While there is a result continue the Loop otherwise stop.
            while(rs.next()){
                double sale = rs.getDouble(2);
                saleValueQ += sale;
                
                // Set maxPurchase if the purchase is greater than maxPurchase.
                if(sale > maxSale) maxSale = sale;
                divider++; // for Later use (getting the average).
            }
            
            // Format value before setting it to their curresponding jLabel for more readability.
            double averageSaleTemp = saleValueQ/divider;
            avgSale.setText(toDecimal.format(averageSaleTemp));
            maxSaleS.setText(toDecimal.format(maxSale));
        
            // Formula for getting the percentage
            double percent = averageSaleTemp/maxSale*100;
        
            // Parse to String and split the decimals, to the value to set t avgPurchase wont contain a decimal otherwise error occurs.
            // Escape "." character;
            String percentString[] = String.valueOf(percent).split("\\.");

            // Get the from percentInt at index 0 and parse to Int.
            avgSalePrice.setValue(Integer.parseInt(percentString[0]));
        }catch(Exception err){
            System.out.println(err);
        }
        
        try{
            String query = "SELECT logistics.Quantity, logistics.Amount, logistics.Order_Type, TIMESTAMPDIFF(Day, logistics.Order_Date, NOW()) FROM logistics;";
            
            // Prepare the query for execution.
            PreparedStatement pst = conn.prepareStatement(query);
            double days_7Purchase = 0;
            double days_30Purchase = 0;
            double quarterPurchase = 0;
            
            double days_7Sale = 0;
            double days_30Sale = 0;
            double quarterSale = 0;
            /* Get Result set.
               ______________________________________________
               | Quantity | Amount | Order_Type | Order_Date |
            */
            ResultSet rs = pst.executeQuery();
            
            // While there is a result continue the Loop otherwise stop.
            while(rs.next()){
                Double amount = rs.getDouble(2);
                String orderType = rs.getString(3);
                int date = rs.getInt(4);
              
                if(date <= 7 && orderType.equalsIgnoreCase("Purchase")){
                    days_7Purchase += amount;
                }else if(date <= 7 && orderType.equalsIgnoreCase("Sale")){
                    days_7Sale =+ amount;
                }else if(date <= 30 && orderType.equalsIgnoreCase("Purchase")){
                    days_30Purchase =+ amount;
                }else if(date <= 30 && orderType.equalsIgnoreCase("Sale")){
                    days_30Sale =+ amount;
                }else if(date <= 90 && orderType.equalsIgnoreCase("Purchase")){
                    quarterPurchase =+ amount;
                }else if(date <= 90 && orderType.equalsIgnoreCase("Sale")){
                    quarterSale =+ amount;
                }
                System.out.println("");
            }
            
            // Convert to String before setting to their corresponding jLabel.
            purchLast7Days.setText(String.valueOf(days_7Purchase));
            purchLast30Days.setText(String.valueOf(days_30Purchase));
            purchLastQuarter.setText(String.valueOf(quarterPurchase));
            saleLast7Days.setText(String.valueOf(days_7Sale));
            saleLast30Days.setText(String.valueOf(days_30Sale));
            saleLastQuarter.setText(String.valueOf(quarterSale));
        }catch(Exception err){
            System.out.println(err);
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        cardBoxParent = new javax.swing.JPanel();
        homeBtn = new javax.swing.JButton();
        inventoryBtn = new javax.swing.JButton();
        logisticBtn = new javax.swing.JButton();
        adminBox = new javax.swing.JLabel();
        aboutUs = new javax.swing.JLabel();
        homeNavigator = new javax.swing.JLabel();
        inventoryNavigator = new javax.swing.JLabel();
        logisticNavigator = new javax.swing.JLabel();
        logOutParent = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        LogOutButton = new javax.swing.JLabel();
        cardBox = new javax.swing.JLabel();
        cardpanel = new javax.swing.JPanel();
        HomePanel = new javax.swing.JPanel();
        banner = new javax.swing.JLabel();
        InventoryPanel = new javax.swing.JPanel();
        filterText = new javax.swing.JLabel();
        categoryFilter = new javax.swing.JComboBox<>();
        searchBox = new javax.swing.JPanel();
        searchField = new javax.swing.JTextField();
        searchLogo = new javax.swing.JLabel();
        inventoryText = new javax.swing.JLabel();
        inventoryBg = new javax.swing.JLabel();
        inventoryTableScroll = new javax.swing.JScrollPane();
        inventoryTable = new javax.swing.JTable();
        inventoryControlBox = new javax.swing.JPanel();
        addBtn = new javax.swing.JButton();
        removeBtn = new javax.swing.JButton();
        sellBtn = new javax.swing.JButton();
        editBtn = new javax.swing.JButton();
        LogisticholdingPanel = new javax.swing.JPanel();
        LogisticPanel = new javax.swing.JPanel();
        INFOButton = new javax.swing.JButton();
        logisticHeader = new javax.swing.JLabel();
        currentStockText = new javax.swing.JLabel();
        stockValueText = new javax.swing.JLabel();
        currentStock = new javax.swing.JLabel();
        stockValue = new javax.swing.JLabel();
        avgPurchasePriceText = new javax.swing.JLabel();
        avgPurchasePrice = new javax.swing.JProgressBar();
        avgPurchase = new javax.swing.JLabel();
        maxPurchaseS = new javax.swing.JLabel();
        avgSalePriceText = new javax.swing.JLabel();
        avgSalePrice = new javax.swing.JProgressBar();
        avgSale = new javax.swing.JLabel();
        maxSaleS = new javax.swing.JLabel();
        statisticsPanel = new javax.swing.JPanel();
        logisticsLogo = new javax.swing.JLabel();
        purchAmount = new javax.swing.JLabel();
        saleAmount = new javax.swing.JLabel();
        last7Days = new javax.swing.JLabel();
        last30Days = new javax.swing.JLabel();
        lastQuarter = new javax.swing.JLabel();
        purchLast7Days = new javax.swing.JLabel();
        saleLast7Days = new javax.swing.JLabel();
        purchLast30Days = new javax.swing.JLabel();
        saleLast30Days = new javax.swing.JLabel();
        purchLastQuarter = new javax.swing.JLabel();
        saleLastQuarter = new javax.swing.JLabel();
        AboutPanel = new javax.swing.JPanel();
        AboutScroll = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("StockFlow Management System");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        cardBoxParent.setBackground(new java.awt.Color(27, 65, 55));
        cardBoxParent.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        homeBtn.setBackground(new java.awt.Color(255, 255, 255));
        homeBtn.setFont(new java.awt.Font("Agency FB", 1, 18)); // NOI18N
        homeBtn.setForeground(new java.awt.Color(254, 113, 2));
        homeBtn.setText("HOME");
        homeBtn.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        homeBtn.setBorderPainted(false);
        homeBtn.setFocusPainted(false);
        homeBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                homeBtnActionPerformed(evt);
            }
        });
        cardBoxParent.add(homeBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(35, 192, 90, -1));

        inventoryBtn.setBackground(new java.awt.Color(255, 255, 255));
        inventoryBtn.setFont(new java.awt.Font("Agency FB", 1, 18)); // NOI18N
        inventoryBtn.setForeground(new java.awt.Color(254, 113, 2));
        inventoryBtn.setText("INVENTORY");
        inventoryBtn.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, null, new java.awt.Color(254, 113, 2), null, null));
        inventoryBtn.setBorderPainted(false);
        inventoryBtn.setFocusPainted(false);
        inventoryBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inventoryBtnActionPerformed(evt);
            }
        });
        cardBoxParent.add(inventoryBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(35, 248, 90, -1));

        logisticBtn.setBackground(new java.awt.Color(255, 255, 255));
        logisticBtn.setFont(new java.awt.Font("Agency FB", 1, 18)); // NOI18N
        logisticBtn.setForeground(new java.awt.Color(254, 113, 2));
        logisticBtn.setText("LOGISTIC");
        logisticBtn.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        logisticBtn.setBorderPainted(false);
        logisticBtn.setFocusPainted(false);
        logisticBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logisticBtnActionPerformed(evt);
            }
        });
        cardBoxParent.add(logisticBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(35, 305, 90, -1));

        adminBox.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/PROFILE ICON.png"))); // NOI18N
        cardBoxParent.add(adminBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        aboutUs.setForeground(new java.awt.Color(254, 113, 2));
        aboutUs.setText("About us");
        aboutUs.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                aboutUsMouseClicked(evt);
            }
        });
        cardBoxParent.add(aboutUs, new org.netbeans.lib.awtextra.AbsoluteConstraints(58, 417, -1, -1));

        homeNavigator.setBackground(new java.awt.Color(0, 0, 0));
        homeNavigator.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 0, 5, new java.awt.Color(225, 139, 25)));
        cardBoxParent.add(homeNavigator, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 191, 10, 30));

        inventoryNavigator.setBackground(new java.awt.Color(0, 0, 0));
        cardBoxParent.add(inventoryNavigator, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 247, 10, 30));

        logisticNavigator.setBackground(new java.awt.Color(0, 0, 0));
        cardBoxParent.add(logisticNavigator, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 304, 10, 30));

        logOutParent.setBackground(new java.awt.Color(35, 46, 63));
        logOutParent.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        logOutParent.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logOutParentMouseClicked(evt);
            }
        });
        logOutParent.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel5.setBackground(new java.awt.Color(35, 46, 63));
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/ic_Logout.png"))); // NOI18N
        jLabel5.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 0, 0, new java.awt.Color(0, 0, 0)));
        logOutParent.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 30, 33));

        LogOutButton.setFont(new java.awt.Font("Century Gothic", 1, 12)); // NOI18N
        LogOutButton.setForeground(new java.awt.Color(255, 255, 255));
        LogOutButton.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LogOutButton.setText("LOG OUT");
        logOutParent.add(LogOutButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 0, 60, 30));

        cardBoxParent.add(logOutParent, new org.netbeans.lib.awtextra.AbsoluteConstraints(35, 369, 90, 30));

        cardBox.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/backgorund.jpg"))); // NOI18N
        cardBox.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 0, 0, new java.awt.Color(0, 0, 0)));
        cardBoxParent.add(cardBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(-3, 0, -1, 490));

        getContentPane().add(cardBoxParent, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 170, 500));

        cardpanel.setBackground(new java.awt.Color(255, 255, 255));
        cardpanel.setLayout(new java.awt.CardLayout());

        HomePanel.setBackground(new java.awt.Color(225, 139, 25));

        banner.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Untitled-1.jpg"))); // NOI18N

        javax.swing.GroupLayout HomePanelLayout = new javax.swing.GroupLayout(HomePanel);
        HomePanel.setLayout(HomePanelLayout);
        HomePanelLayout.setHorizontalGroup(
            HomePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(banner)
        );
        HomePanelLayout.setVerticalGroup(
            HomePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(HomePanelLayout.createSequentialGroup()
                .addComponent(banner, javax.swing.GroupLayout.PREFERRED_SIZE, 265, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 235, Short.MAX_VALUE))
        );

        cardpanel.add(HomePanel, "card2");

        InventoryPanel.setBackground(new java.awt.Color(255, 255, 255));
        InventoryPanel.setPreferredSize(new java.awt.Dimension(610, 500));
        InventoryPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        filterText.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        filterText.setForeground(new java.awt.Color(27, 65, 55));
        filterText.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        filterText.setText("Filter by Category: ");
        filterText.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 2, 0, 0, new java.awt.Color(27, 65, 55)));
        InventoryPanel.add(filterText, new org.netbeans.lib.awtextra.AbsoluteConstraints(325, 69, 140, 25));

        categoryFilter.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ALL", "Electronics", "Housekeeping", "Sports and Fitness", "Kitchen Applicances", "Miscellaneous" }));
        categoryFilter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                categoryFilterActionPerformed(evt);
            }
        });
        InventoryPanel.add(categoryFilter, new org.netbeans.lib.awtextra.AbsoluteConstraints(459, 70, -1, -1));

        searchBox.setBackground(new java.awt.Color(255, 255, 255));
        searchBox.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 0, new java.awt.Color(35, 46, 63)));
        searchBox.setForeground(new java.awt.Color(153, 153, 153));
        searchBox.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        searchField.setBackground(new java.awt.Color(255, 255, 255));
        searchField.setForeground(new java.awt.Color(153, 153, 153));
        searchField.setText("Search");
        searchField.setBorder(null);
        searchField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                searchFieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                searchFieldFocusLost(evt);
            }
        });
        searchField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                searchFieldKeyReleased(evt);
            }
        });
        searchBox.add(searchField, new org.netbeans.lib.awtextra.AbsoluteConstraints(18, -2, 120, 20));

        searchLogo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/search.png"))); // NOI18N
        searchBox.add(searchLogo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        InventoryPanel.add(searchBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 70, 160, 20));

        inventoryText.setBackground(new java.awt.Color(255, 255, 255));
        inventoryText.setFont(new java.awt.Font("Century Gothic", 1, 24)); // NOI18N
        inventoryText.setForeground(new java.awt.Color(27, 65, 55));
        inventoryText.setText("INVENTORY");
        InventoryPanel.add(inventoryText, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 62, 140, 30));
        InventoryPanel.add(inventoryBg, new org.netbeans.lib.awtextra.AbsoluteConstraints(-3, -4, 620, 500));

        inventoryTableScroll.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        inventoryTable.setBackground(new java.awt.Color(255, 255, 255));
        inventoryTable.setFont(new java.awt.Font("Agency FB", 0, 12)); // NOI18N
        inventoryTable.setForeground(new java.awt.Color(0, 0, 0));
        inventoryTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Product Name", "Purch. Price", "Sales Value", "Available Stock"
            }
        ));
        inventoryTable.setEnabled(false);
        inventoryTable.setPreferredSize(new java.awt.Dimension(300, 1020));
        inventoryTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                inventoryTableMouseClicked(evt);
            }
        });
        inventoryTableScroll.setViewportView(inventoryTable);
        inventoryTable.setSelectionMode(0);

        InventoryPanel.add(inventoryTableScroll, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 109, 597, 284));

        inventoryControlBox.setBackground(new java.awt.Color(255, 255, 255));
        inventoryControlBox.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 0, 0, 0, new java.awt.Color(35, 46, 63)));

        addBtn.setBackground(new java.awt.Color(255, 255, 255));
        addBtn.setFont(new java.awt.Font("Agency FB", 1, 12)); // NOI18N
        addBtn.setForeground(new java.awt.Color(27, 65, 55));
        addBtn.setText("ADD");
        addBtn.setFocusPainted(false);
        addBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addBtnActionPerformed(evt);
            }
        });

        removeBtn.setBackground(new java.awt.Color(255, 255, 255));
        removeBtn.setFont(new java.awt.Font("Agency FB", 1, 12)); // NOI18N
        removeBtn.setForeground(new java.awt.Color(27, 65, 55));
        removeBtn.setText("REMOVE");
        removeBtn.setFocusPainted(false);
        removeBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                removeBtnActionPerformed(evt);
            }
        });

        sellBtn.setBackground(new java.awt.Color(255, 255, 255));
        sellBtn.setFont(new java.awt.Font("Agency FB", 1, 12)); // NOI18N
        sellBtn.setForeground(new java.awt.Color(27, 65, 55));
        sellBtn.setText("SELL");
        sellBtn.setFocusPainted(false);
        sellBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sellBtnActionPerformed(evt);
            }
        });

        editBtn.setBackground(new java.awt.Color(255, 255, 255));
        editBtn.setFont(new java.awt.Font("Agency FB", 1, 12)); // NOI18N
        editBtn.setForeground(new java.awt.Color(27, 65, 55));
        editBtn.setText("EDIT");
        editBtn.setFocusPainted(false);
        editBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout inventoryControlBoxLayout = new javax.swing.GroupLayout(inventoryControlBox);
        inventoryControlBox.setLayout(inventoryControlBoxLayout);
        inventoryControlBoxLayout.setHorizontalGroup(
            inventoryControlBoxLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(inventoryControlBoxLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(addBtn, javax.swing.GroupLayout.DEFAULT_SIZE, 204, Short.MAX_VALUE)
                .addGap(5, 5, 5)
                .addComponent(removeBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(sellBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(107, 107, 107)
                .addComponent(editBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14))
        );
        inventoryControlBoxLayout.setVerticalGroup(
            inventoryControlBoxLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(inventoryControlBoxLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(inventoryControlBoxLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(addBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(removeBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(editBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(sellBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(27, Short.MAX_VALUE))
        );

        InventoryPanel.add(inventoryControlBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 405, -1, -1));

        cardpanel.add(InventoryPanel, "card3");

        LogisticholdingPanel.setLayout(new java.awt.CardLayout());

        LogisticPanel.setBackground(new java.awt.Color(255, 255, 255));

        INFOButton.setText("INFO");
        INFOButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                INFOButtonActionPerformed(evt);
            }
        });

        logisticHeader.setFont(new java.awt.Font("Century Gothic", 1, 36)); // NOI18N
        logisticHeader.setForeground(new java.awt.Color(27, 65, 55));
        logisticHeader.setText("LOGISTIC");

        currentStockText.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        currentStockText.setForeground(new java.awt.Color(27, 65, 55));
        currentStockText.setText("Current Stock");
        currentStockText.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(27, 65, 55)));

        stockValueText.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        stockValueText.setForeground(new java.awt.Color(27, 65, 55));
        stockValueText.setText("Stock Value");
        stockValueText.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(27, 65, 55)));

        currentStock.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N
        currentStock.setForeground(new java.awt.Color(27, 65, 55));
        currentStock.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        currentStock.setText("0");

        stockValue.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N
        stockValue.setForeground(new java.awt.Color(27, 65, 55));
        stockValue.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        stockValue.setText("0");

        avgPurchasePriceText.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        avgPurchasePriceText.setForeground(new java.awt.Color(27, 65, 55));
        avgPurchasePriceText.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        avgPurchasePriceText.setText("<html><p style=\"text-align: center\">Average<br>Purchase Price</p></html>");
        avgPurchasePriceText.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(27, 65, 55)));

        avgPurchasePrice.setForeground(new java.awt.Color(27, 65, 55));

        avgPurchase.setFont(new java.awt.Font("Century Gothic", 0, 12)); // NOI18N
        avgPurchase.setForeground(new java.awt.Color(27, 65, 55));
        avgPurchase.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        avgPurchase.setText("0");

        maxPurchaseS.setFont(new java.awt.Font("Century Gothic", 0, 12)); // NOI18N
        maxPurchaseS.setForeground(new java.awt.Color(27, 65, 55));
        maxPurchaseS.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        maxPurchaseS.setText("0");

        avgSalePriceText.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        avgSalePriceText.setForeground(new java.awt.Color(27, 65, 55));
        avgSalePriceText.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        avgSalePriceText.setText("<html><p style=\"text-align: center\">Average<br>Sale Price</p></html>");
        avgSalePriceText.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(27, 65, 55)));

        avgSalePrice.setForeground(new java.awt.Color(27, 65, 55));

        avgSale.setFont(new java.awt.Font("Century Gothic", 0, 12)); // NOI18N
        avgSale.setForeground(new java.awt.Color(27, 65, 55));
        avgSale.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        avgSale.setText("0");

        maxSaleS.setFont(new java.awt.Font("Century Gothic", 0, 12)); // NOI18N
        maxSaleS.setForeground(new java.awt.Color(27, 65, 55));
        maxSaleS.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        maxSaleS.setText("0");

        statisticsPanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(27, 65, 55)));
        statisticsPanel.setForeground(new java.awt.Color(27, 65, 55));
        statisticsPanel.setOpaque(false);

        logisticsLogo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Icons/graph.png"))); // NOI18N

        purchAmount.setFont(new java.awt.Font("Century Gothic", 1, 12)); // NOI18N
        purchAmount.setForeground(new java.awt.Color(27, 65, 55));
        purchAmount.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        purchAmount.setText("<html><p style=\"text-align: center\">Purchase<br>Amount</p></html>");
        purchAmount.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(27, 65, 55)));

        saleAmount.setFont(new java.awt.Font("Century Gothic", 1, 12)); // NOI18N
        saleAmount.setForeground(new java.awt.Color(27, 65, 55));
        saleAmount.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        saleAmount.setText("<html><p style=\"text-align: center\">Sale<br>Amount</p></html>");
        saleAmount.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 1, 0, new java.awt.Color(27, 65, 55)));

        last7Days.setFont(new java.awt.Font("Century Gothic", 1, 12)); // NOI18N
        last7Days.setForeground(new java.awt.Color(27, 65, 55));
        last7Days.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        last7Days.setText("Last 7 Days");

        last30Days.setFont(new java.awt.Font("Century Gothic", 1, 12)); // NOI18N
        last30Days.setForeground(new java.awt.Color(27, 65, 55));
        last30Days.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        last30Days.setText("Last 30 Days");

        lastQuarter.setFont(new java.awt.Font("Century Gothic", 1, 12)); // NOI18N
        lastQuarter.setForeground(new java.awt.Color(27, 65, 55));
        lastQuarter.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lastQuarter.setText("Last Quarter");

        purchLast7Days.setFont(new java.awt.Font("Century Gothic", 1, 12)); // NOI18N
        purchLast7Days.setForeground(new java.awt.Color(27, 65, 55));
        purchLast7Days.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        purchLast7Days.setText("0");

        saleLast7Days.setFont(new java.awt.Font("Century Gothic", 1, 12)); // NOI18N
        saleLast7Days.setForeground(new java.awt.Color(27, 65, 55));
        saleLast7Days.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        saleLast7Days.setText("0");

        purchLast30Days.setFont(new java.awt.Font("Century Gothic", 1, 12)); // NOI18N
        purchLast30Days.setForeground(new java.awt.Color(27, 65, 55));
        purchLast30Days.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        purchLast30Days.setText("0");

        saleLast30Days.setFont(new java.awt.Font("Century Gothic", 1, 12)); // NOI18N
        saleLast30Days.setForeground(new java.awt.Color(27, 65, 55));
        saleLast30Days.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        saleLast30Days.setText("0");

        purchLastQuarter.setFont(new java.awt.Font("Century Gothic", 1, 12)); // NOI18N
        purchLastQuarter.setForeground(new java.awt.Color(27, 65, 55));
        purchLastQuarter.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        purchLastQuarter.setText("0");

        saleLastQuarter.setFont(new java.awt.Font("Century Gothic", 1, 12)); // NOI18N
        saleLastQuarter.setForeground(new java.awt.Color(27, 65, 55));
        saleLastQuarter.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        saleLastQuarter.setText("0");

        javax.swing.GroupLayout statisticsPanelLayout = new javax.swing.GroupLayout(statisticsPanel);
        statisticsPanel.setLayout(statisticsPanelLayout);
        statisticsPanelLayout.setHorizontalGroup(
            statisticsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(statisticsPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(statisticsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(statisticsPanelLayout.createSequentialGroup()
                        .addGroup(statisticsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(statisticsPanelLayout.createSequentialGroup()
                                .addComponent(last30Days)
                                .addGap(5, 5, 5)
                                .addComponent(purchLast30Days, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(saleLast30Days, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(statisticsPanelLayout.createSequentialGroup()
                                .addComponent(lastQuarter)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(purchLastQuarter, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(saleLastQuarter, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, statisticsPanelLayout.createSequentialGroup()
                        .addGroup(statisticsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(statisticsPanelLayout.createSequentialGroup()
                                .addGap(21, 21, 21)
                                .addComponent(logisticsLogo))
                            .addComponent(last7Days))
                        .addGroup(statisticsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(statisticsPanelLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(purchAmount, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(saleAmount, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(23, 23, 23))
                            .addGroup(statisticsPanelLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(purchLast7Days, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(saleLast7Days, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap())))))
        );
        statisticsPanelLayout.setVerticalGroup(
            statisticsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(statisticsPanelLayout.createSequentialGroup()
                .addGroup(statisticsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(statisticsPanelLayout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addGroup(statisticsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(purchAmount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(saleAmount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(statisticsPanelLayout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(logisticsLogo)))
                .addGap(18, 18, 18)
                .addGroup(statisticsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(last7Days)
                    .addComponent(purchLast7Days)
                    .addComponent(saleLast7Days))
                .addGap(18, 18, 18)
                .addGroup(statisticsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(statisticsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(purchLast30Days)
                        .addComponent(saleLast30Days))
                    .addComponent(last30Days))
                .addGap(18, 18, 18)
                .addGroup(statisticsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(statisticsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(purchLastQuarter)
                        .addComponent(saleLastQuarter))
                    .addComponent(lastQuarter))
                .addContainerGap(15, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout LogisticPanelLayout = new javax.swing.GroupLayout(LogisticPanel);
        LogisticPanel.setLayout(LogisticPanelLayout);
        LogisticPanelLayout.setHorizontalGroup(
            LogisticPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(LogisticPanelLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(LogisticPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(LogisticPanelLayout.createSequentialGroup()
                        .addComponent(logisticHeader, javax.swing.GroupLayout.PREFERRED_SIZE, 346, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, LogisticPanelLayout.createSequentialGroup()
                        .addGroup(LogisticPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(LogisticPanelLayout.createSequentialGroup()
                                .addComponent(avgSale, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(maxSaleS, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, LogisticPanelLayout.createSequentialGroup()
                                .addGroup(LogisticPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(currentStock, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(currentStockText))
                                .addGap(18, 18, 18)
                                .addGroup(LogisticPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(stockValueText, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(stockValue, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(avgSalePrice, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(avgPurchasePriceText, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(avgPurchasePrice, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(avgSalePriceText, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(LogisticPanelLayout.createSequentialGroup()
                                .addComponent(avgPurchase, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(maxPurchaseS, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGap(28, 28, 28)
                        .addGroup(LogisticPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(statisticsPanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(INFOButton, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(27, 27, 27))))
        );
        LogisticPanelLayout.setVerticalGroup(
            LogisticPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(LogisticPanelLayout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(logisticHeader, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(LogisticPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(LogisticPanelLayout.createSequentialGroup()
                        .addGap(9, 9, 9)
                        .addComponent(statisticsPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(77, 77, 77)
                        .addComponent(avgSalePriceText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(LogisticPanelLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(LogisticPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(currentStockText)
                            .addComponent(stockValueText))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(LogisticPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(currentStock)
                            .addComponent(stockValue))
                        .addGap(50, 50, 50)
                        .addComponent(avgPurchasePriceText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(avgPurchasePrice, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(LogisticPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(maxPurchaseS)
                            .addComponent(avgPurchase))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(avgSalePrice, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(LogisticPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(LogisticPanelLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(LogisticPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(maxSaleS)
                            .addComponent(avgSale)))
                    .addGroup(LogisticPanelLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(INFOButton, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(30, Short.MAX_VALUE))
        );

        LogisticholdingPanel.add(LogisticPanel, "card3");

        cardpanel.add(LogisticholdingPanel, "card7");

        AboutPanel.setBackground(new java.awt.Color(255, 255, 255));
        AboutPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        AboutScroll.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 0, 0, new java.awt.Color(0, 0, 0)));
        AboutScroll.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        jTextArea1.setEditable(false);
        jTextArea1.setBackground(new java.awt.Color(255, 255, 255));
        jTextArea1.setColumns(20);
        jTextArea1.setForeground(new java.awt.Color(0, 0, 0));
        jTextArea1.setLineWrap(true);
        jTextArea1.setRows(5);
        jTextArea1.setText("About Us\n\nWelcome to StockFlow, your trusted partner in inventory management solutions. \nWe are a team of innovators dedicated to simplifying the way businesses handle their \nstock, ensuring efficiency, accuracy, and transparency in every transaction.\n\nOur Mission\n\nAt StockFlow, our mission is to empower businesses with cutting-edge tools that\n\n streamline inventory processes, reduce manual errors, and drive operational excellence. \nWe believe that effective inventory management is the backbone of any successful business.\n\nWhat We Offer\n\nStockFlow is more than just an inventory system—it’s a comprehensive platform \ndesigned to meet your unique needs. Whether you’re tracking raw materials, managing finished \ngoods, or monitoring stock levels, our system provides:\n\nReal-Time Tracking: Stay updated with accurate inventory levels at any time.\n\nCustomizable Features: Tailor the system to fit your business requirements.\n\nDetailed Reporting: Gain insights into stock trends and operational performance.\n\nUser-Friendly Interface: Simplify training and daily use for your team.\n\nWhy Choose Us?\n\nWe understand the challenges that come with inventory management, and we’re here to help. \nStockFlow is built on the principles of reliability, security, and adaptability. With us, you’ll experience:\n\nScalable Solutions: Perfect for businesses of all sizes.\n\nSeamless Integration: Works effortlessly with your existing systems.\n\nExceptional Support: Our team is always ready to assist you.\n\nJoin Us on the Journey\n\nBy choosing StockFlow, you’re not just investing in software; you’re partnering with a team committed\n to your success. Let’s optimize your inventory management and drive your business forward.\n\nThank you for trusting StockFlow. Together, we’ll make inventory management effortless and effective.\n");
        jTextArea1.setBorder(null);
        jTextArea1.setMargin(new java.awt.Insets(2, 10, 2, 10));
        jTextArea1.setRequestFocusEnabled(false);
        AboutScroll.setViewportView(jTextArea1);

        AboutPanel.add(AboutScroll, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 600, 430));

        cardpanel.add(AboutPanel, "card5");

        getContentPane().add(cardpanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 0, 610, 500));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void logisticBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logisticBtnActionPerformed
        resetNavigator();
        cardpanel.removeAll();
        cardpanel.add(LogisticPanel);
        cardpanel.repaint();
        cardpanel.revalidate();
        logisticNavigator.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 0, 5, new java.awt.Color(225,139,25)));
    }//GEN-LAST:event_logisticBtnActionPerformed

    private void inventoryBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inventoryBtnActionPerformed
        resetNavigator();
        cardpanel.removeAll();
        cardpanel.add(InventoryPanel);
        cardpanel.repaint();
        cardpanel.revalidate();
        inventoryNavigator.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 0, 5, new java.awt.Color(225,139,25)));
    }//GEN-LAST:event_inventoryBtnActionPerformed

    private void homeBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_homeBtnActionPerformed
        resetNavigator();
        cardpanel.removeAll();
        cardpanel.add(HomePanel);
        cardpanel.repaint();
        cardpanel.revalidate();
        homeNavigator.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 0, 5, new java.awt.Color(225,139,25)));
    }//GEN-LAST:event_homeBtnActionPerformed
  
    private void aboutUsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_aboutUsMouseClicked
        // TODO add your handling code here:
        cardpanel.removeAll();
        cardpanel.add(AboutPanel);
        cardpanel.repaint();
        cardpanel.revalidate();
    }//GEN-LAST:event_aboutUsMouseClicked

    private void INFOButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_INFOButtonActionPerformed
        cardpanel.removeAll();
        cardpanel.add(LogisticPanel);
        cardpanel.repaint();
        cardpanel.revalidate();

        new LogisticInfo(null, true).show();
    }//GEN-LAST:event_INFOButtonActionPerformed

    private void addBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addBtnActionPerformed
        cardpanel.removeAll();
        cardpanel.add(InventoryPanel);
        cardpanel.repaint();
        cardpanel.revalidate();

        AddInventory add = new AddInventory(null, true);
        add.show();
        if(add.isItemAdded){
            setInventoryTable();
        }
    }//GEN-LAST:event_addBtnActionPerformed

    private void logOutParentMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logOutParentMouseClicked
        Logout_pop_up LC = new Logout_pop_up(null, true, adminID, isSessionSaved);
        LC.show();
        if(LC.inOut==1){
            this.setVisible(false);
        }
    }//GEN-LAST:event_logOutParentMouseClicked

    private void searchFieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_searchFieldFocusGained
        if(searchField.getText().equals("Search")){
            searchField.setText("");
            searchField.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_searchFieldFocusGained

    private void searchFieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_searchFieldFocusLost
        if(searchField.getText().isEmpty()){
            searchField.setText("Search");
            searchField.setForeground(Color.GRAY);
        }
    }//GEN-LAST:event_searchFieldFocusLost

    private void editBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editBtnActionPerformed
        if(editBtn.getForeground().getBlue()==255){
            inventoryTable.setEnabled(false);
            inventoryTable.removeEditor();
            inventoryTable.setSelectionMode(0);
            editBtn.setForeground(new Color(0x276555));
            editBtn.setBackground(null);
        }else{
            inventoryTable.setEnabled(true);
            editBtn.setForeground(Color.WHITE);
            editBtn.setBackground(new Color(0x269963));
        }
    }//GEN-LAST:event_editBtnActionPerformed

    private void categoryFilterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_categoryFilterActionPerformed
        searchFilterCategory = categoryFilter.getSelectedItem().toString();
        if(searchField.getText().isEmpty() || searchField.getText().equals("Search")){
            isSearching = false;
        }else{
            isSearching = true;
        }
        setInventoryTable();
    }//GEN-LAST:event_categoryFilterActionPerformed

    private void searchFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchFieldKeyReleased
        searchFilter = searchField.getText();
        if(searchField.getText().isEmpty()){
            isSearching = false;
        }else{
            isSearching = true;
        }
        setInventoryTable();
    }//GEN-LAST:event_searchFieldKeyReleased

    private void inventoryTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_inventoryTableMouseClicked
        int row = inventoryTable.getSelectedRow();
        if(editBtn.getForeground().getBlue()==255 && inventoryTable.isEnabled() && row != -1){
            Utilities.Edit_Inventory updateItem = new Utilities.Edit_Inventory(null, true, inventoryTable.getValueAt(row, 0).toString(), inventoryTable.getValueAt(row, 1).toString(), inventoryTable.getValueAt(row, 2).toString(), inventoryTable.getValueAt(row, 3).toString(), itemsCategory.get(row), inventoryTable.getValueAt(row, 4).toString());
            updateItem.show();
            if(updateItem.isItemUpdated){
                setInventoryTable();
            }
        }else if(sellBtn.getForeground().getGreen()==255 && inventoryTable.isEnabled() && row != -1){
            Utilities.Sell_Item sellItem = new Utilities.Sell_Item(null, true, inventoryTable.getValueAt(row, 0).toString(), inventoryTable.getValueAt(row, 1).toString(), inventoryTable.getValueAt(row, 2).toString(), inventoryTable.getValueAt(row, 3).toString(), inventoryTable.getValueAt(row, 4).toString());
            sellItem.show();
            if(sellItem.isItemSold){
                setInventoryTable();
            }
        }else if(removeBtn.getForeground().getRed()==255 && inventoryTable.isEnabled() && row != -1){
            Utilities.Remove_Item removeItem = new Utilities.Remove_Item(null, true, inventoryTable.getValueAt(row, 0).toString(), inventoryTable.getValueAt(row, 1).toString(), inventoryTable.getValueAt(row, 2).toString(), inventoryTable.getValueAt(row, 3).toString(), inventoryTable.getValueAt(row, 4).toString());
            removeItem.show();
            if(removeItem.isItemRemoved){
                setInventoryTable();
            }
        }
    }//GEN-LAST:event_inventoryTableMouseClicked

    private void sellBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sellBtnActionPerformed
        if(sellBtn.getForeground().getGreen()==255){
            inventoryTable.setEnabled(false);
            inventoryTable.removeEditor();
            inventoryTable.setSelectionMode(0);
            sellBtn.setForeground(new Color(0x276555));
            sellBtn.setBackground(null);
        }else{
            inventoryTable.setEnabled(true);
            sellBtn.setForeground(Color.WHITE);
            sellBtn.setBackground(new Color(0xD5BA48));
        }
    }//GEN-LAST:event_sellBtnActionPerformed

    private void removeBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_removeBtnActionPerformed
        if(removeBtn.getForeground().getGreen()==255){
            inventoryTable.setEnabled(false);
            inventoryTable.removeEditor();
            inventoryTable.setSelectionMode(0);
            removeBtn.setForeground(new Color(0x276555));
            removeBtn.setBackground(null);
        }else{
            inventoryTable.setEnabled(true);
            removeBtn.setForeground(Color.WHITE);
            removeBtn.setBackground(new Color(0xFF2936));
        }
    }//GEN-LAST:event_removeBtnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                //new Home().setVisible(true);
               Main.run();
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel AboutPanel;
    private javax.swing.JScrollPane AboutScroll;
    private javax.swing.JPanel HomePanel;
    private javax.swing.JButton INFOButton;
    private javax.swing.JPanel InventoryPanel;
    private javax.swing.JLabel LogOutButton;
    private javax.swing.JPanel LogisticPanel;
    private javax.swing.JPanel LogisticholdingPanel;
    private javax.swing.JLabel aboutUs;
    private javax.swing.JButton addBtn;
    private javax.swing.JLabel adminBox;
    private javax.swing.JLabel avgPurchase;
    private javax.swing.JProgressBar avgPurchasePrice;
    private javax.swing.JLabel avgPurchasePriceText;
    private javax.swing.JLabel avgSale;
    private javax.swing.JProgressBar avgSalePrice;
    private javax.swing.JLabel avgSalePriceText;
    private javax.swing.JLabel banner;
    private javax.swing.JLabel cardBox;
    private javax.swing.JPanel cardBoxParent;
    private javax.swing.JPanel cardpanel;
    private javax.swing.JComboBox<String> categoryFilter;
    private javax.swing.JLabel currentStock;
    private javax.swing.JLabel currentStockText;
    private javax.swing.JButton editBtn;
    private javax.swing.JLabel filterText;
    private javax.swing.JButton homeBtn;
    private javax.swing.JLabel homeNavigator;
    private javax.swing.JLabel inventoryBg;
    private javax.swing.JButton inventoryBtn;
    private javax.swing.JPanel inventoryControlBox;
    private javax.swing.JLabel inventoryNavigator;
    private javax.swing.JTable inventoryTable;
    private javax.swing.JScrollPane inventoryTableScroll;
    private javax.swing.JLabel inventoryText;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JLabel last30Days;
    private javax.swing.JLabel last7Days;
    private javax.swing.JLabel lastQuarter;
    private javax.swing.JPanel logOutParent;
    private javax.swing.JButton logisticBtn;
    private javax.swing.JLabel logisticHeader;
    private javax.swing.JLabel logisticNavigator;
    private javax.swing.JLabel logisticsLogo;
    private javax.swing.JLabel maxPurchaseS;
    private javax.swing.JLabel maxSaleS;
    private javax.swing.JLabel purchAmount;
    private javax.swing.JLabel purchLast30Days;
    private javax.swing.JLabel purchLast7Days;
    private javax.swing.JLabel purchLastQuarter;
    private javax.swing.JButton removeBtn;
    private javax.swing.JLabel saleAmount;
    private javax.swing.JLabel saleLast30Days;
    private javax.swing.JLabel saleLast7Days;
    private javax.swing.JLabel saleLastQuarter;
    private javax.swing.JPanel searchBox;
    private javax.swing.JTextField searchField;
    private javax.swing.JLabel searchLogo;
    private javax.swing.JButton sellBtn;
    private javax.swing.JPanel statisticsPanel;
    private javax.swing.JLabel stockValue;
    private javax.swing.JLabel stockValueText;
    // End of variables declaration//GEN-END:variables
}
