/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package Utilities;

import MainSystem.*;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;

/**
 *
 * @author crissa jean pagapong
 */
public class Edit_Inventory extends javax.swing.JDialog {
    Connection conn = new Database.Db_conn().conn();
    DefaultComboBoxModel filter = new DefaultComboBoxModel(new String[]{"Electronics", "Housekeeping", "Sports and Fitness", "Kitchen Applicances", "Utility", "Miscellaneous"});
    public boolean isItemUpdated = false;
    
    String prodID;
    String prodName;
    String prodCategory;
    String prodPrice;
    String prodSale;
    String prodQuantity;
    /**
     * Creates new form addinventory
     */
    public Edit_Inventory(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        categoryFilter.setModel(filter);
        categoryFilter.setSelectedItem("Miscellaneous");
    }
    
    public Edit_Inventory(java.awt.Frame parent, boolean modal, String ID, String prod_name, String prod_price, String prod_sale, String category, String quantity) {
        super(parent, modal);
        initComponents();
        categoryFilter.setModel(filter);
        categoryFilter.setSelectedItem(category);
        prodID = ID;
        prodName = prod_name;
        prodCategory = category;
        prodPrice = prod_price.replaceAll(",", "");
        prodSale = prod_sale;
        prodQuantity = quantity;
        productName.setText(prod_name);
        productPrice.setText(prod_price);
        salesValue.setText(prod_sale);
        this.quantity.setValue(Integer.parseInt(quantity));
    }
    
    public void updateItem(String prod_name, String prod_price, String prod_sale, String category){
        if(prodName.equals(productName.getText()) && prodPrice.equals(productPrice.getText()) && prodSale.equals(salesValue.getText()) && prodCategory.equals(categoryFilter.getSelectedItem().toString()) && prodQuantity.equals(quantity.getValue().toString())){
            // Do Nothing
            this.dispose();
        }else{
            DecimalFormat toDecimal = new DecimalFormat("#,###.00");
            String invalidP[] = prod_price.split("\\.");
            String invalidPS[] = prod_sale.split("\\.");
            errorPrice.setText("");
            errorSales.setText("");

            boolean isError = false;
            if(invalidP.length > 2 || prod_price.matches("[0-9]*\\.{2,}") || prod_price.matches(".*\\.$") || prod_price.matches("[a-zA-Z]*")) {
                //new PopUp_Messages.Invalid_Add_Item(null, true, "Invalid Price!").show();
                errorPrice.setText("Invalid Price Value!");
                isError = true;
            }
            if(invalidPS.length > 2 || prod_sale.matches("[0-9]*\\.{2,}") || prod_sale.matches(".*\\.$") || prod_sale.matches("[a-zA-Z]*")){
                //new PopUp_Messages.Invalid_Add_Item(null, true, "Invalid Price!").show();
                errorSales.setText("Invalid Sales Value!");
                isError = true;
            }
            if(!isError){     
                String formatPrice = prod_price.replaceAll(",", "");
                Double prod_Price = Double.parseDouble(formatPrice);

                String formatSale = prod_sale.replaceAll(",", "");
                Double prod_Sale = Double.parseDouble(formatSale);
                int prodQ = Integer.parseInt(quantity.getValue().toString());
                String query = "UPDATE inventory SET Product_Name = '"+prod_name+"', Product_Category = '"+category+"', Product_Price = '"+prod_Price+"', Product_Sales_Value = '"+prod_Sale+"', Product_Stock = '"+prodQ+"' WHERE Product_ID = '"+prodID+"';";
                try{
                    PreparedStatement pst = conn.prepareStatement(query);
                    pst.execute();
                    
                    try{    
                        double total = Double.parseDouble(prodPrice) * (Integer.parseInt(quantity.getValue().toString()) - Integer.parseInt(prodQuantity));
                        
                        if(prodQ-Integer.parseInt(prodQuantity) < 0){
                            query = "INSERT INTO logistics VALUES (null, 'Remove', '"+prodID+"', '"+Math.abs(prodQ-Integer.parseInt(prodQuantity))+"', '"+prodPrice+"', NOW(), '"+Math.abs(total)+"');";       
                        }else{
                            query = "INSERT INTO logistics VALUES (null, 'Purchase', '"+prodID+"', '"+Math.abs(prodQ-Integer.parseInt(prodQuantity))+"', '"+prodPrice+"', NOW(), '"+Math.abs(total)+"');";
                        }
                        
                        pst = conn.prepareStatement(query);
                        pst.execute();
                        
                        query = "SELECT * FROM item_info WHERE Item_Name = '"+prod_name+"';";
                        pst = conn.prepareStatement(query);
                        ResultSet rs = pst.executeQuery();
                        
                        if(!rs.next()){
                            query = "INSERT INTO item_info VALUES ('"+prodID+"','"+prod_name+"','"+prodCategory+"');";
                            pst = conn.prepareStatement(query);
                            pst.execute();
                        }
                        
                        isItemUpdated = true;
                        new PopUp_Messages.Add_Product_Message(null, true, "Edited Successfully").show();
                        this.dispose();
                    }catch(SQLException i){
                        System.out.println(i);
                    }
                }catch(SQLException e){
                    System.out.println(e);
                    e.printStackTrace();
                }
            }
        }
    }
    
    public void resetFieldError(){
        productName.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, null, null));
        productPrice.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, null, null));
        salesValue.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, null, null));
        categoryFilter.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, null, null));
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        addProductheader = new javax.swing.JLabel();
        productNameText = new javax.swing.JLabel();
        productName = new javax.swing.JTextField();
        productPriceText = new javax.swing.JLabel();
        productPrice = new javax.swing.JTextField();
        errorPrice = new javax.swing.JLabel();
        salesValueText = new javax.swing.JLabel();
        salesValue = new javax.swing.JTextField();
        addProductBtn = new javax.swing.JButton();
        categoryFilter = new javax.swing.JComboBox<>();
        errorSales = new javax.swing.JLabel();
        productPriceText1 = new javax.swing.JLabel();
        quantity = new javax.swing.JSpinner();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(26, 102, 63));

        addProductheader.setBackground(new java.awt.Color(61, 211, 123));
        addProductheader.setFont(new java.awt.Font("Century Gothic", 1, 36)); // NOI18N
        addProductheader.setForeground(new java.awt.Color(61, 211, 123));
        addProductheader.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        addProductheader.setText("EDIT PRODUCT");

        productNameText.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        productNameText.setForeground(new java.awt.Color(61, 211, 123));
        productNameText.setText("Product Name");

        productName.setBackground(new java.awt.Color(255, 255, 255));

        productPriceText.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        productPriceText.setForeground(new java.awt.Color(61, 211, 123));
        productPriceText.setText("Purchase Price");

        productPrice.setBackground(new java.awt.Color(255, 255, 255));

        errorPrice.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        errorPrice.setForeground(new java.awt.Color(255, 65, 55));
        errorPrice.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);

        salesValueText.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        salesValueText.setForeground(new java.awt.Color(61, 211, 123));
        salesValueText.setText("Sales Value");

        salesValue.setBackground(new java.awt.Color(255, 255, 255));

        addProductBtn.setBackground(new java.awt.Color(255, 255, 255));
        addProductBtn.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        addProductBtn.setForeground(new java.awt.Color(27, 65, 55));
        addProductBtn.setText("CONFIRM");
        addProductBtn.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        addProductBtn.setFocusable(false);
        addProductBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addProductBtnActionPerformed(evt);
            }
        });

        categoryFilter.setForeground(new java.awt.Color(61, 211, 123));
        categoryFilter.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        categoryFilter.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(61, 211, 123), 1, true));

        errorSales.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        errorSales.setForeground(new java.awt.Color(255, 65, 55));
        errorSales.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);

        productPriceText1.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        productPriceText1.setForeground(new java.awt.Color(61, 211, 123));
        productPriceText1.setText("Quantity");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(51, 51, 51)
                        .addComponent(addProductheader, javax.swing.GroupLayout.PREFERRED_SIZE, 255, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(salesValueText, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(salesValue, javax.swing.GroupLayout.PREFERRED_SIZE, 299, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(productPriceText1)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(quantity, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(addProductBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(0, 0, 0)
                                .addComponent(errorSales, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                    .addComponent(productNameText, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(categoryFilter, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(productName, javax.swing.GroupLayout.PREFERRED_SIZE, 299, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                    .addComponent(productPriceText, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(0, 0, 0)
                                    .addComponent(errorPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(productPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 299, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(addProductheader, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(categoryFilter, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(productNameText, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(productName, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(errorPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 17, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(productPriceText, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(productPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(errorSales, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(salesValueText)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(salesValue, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(productPriceText1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(quantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addContainerGap(48, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(addProductBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(17, 17, 17))))))
        );

        quantity.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                if(Integer.parseInt(quantity.getValue().toString())<=1){
                    quantity.setValue(1);
                }
            }
        });

        quantity.setForeground(new java.awt.Color(0x619912));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 370, 390));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void addProductBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addProductBtnActionPerformed
        String prod_name = productName.getText();
        String prod_price = productPrice.getText();
        String prod_sale = salesValue.getText();
        String category = categoryFilter.getSelectedItem().toString();
        
        resetFieldError();
        if(prod_name.isEmpty() || prod_price.isEmpty() || prod_sale.isEmpty()){
            new PopUp_Messages.Invalid_Input_Item(null, true, "Please Fill All The Fields!").show();
            if(prod_name.isEmpty()) productName.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255,65,55)));
            if(prod_price.isEmpty()) productPrice.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255,65,55)));
            if(prod_sale.isEmpty()) salesValue.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255,65,55)));
        }else{
            updateItem(prod_name, prod_price, prod_sale, category);
        }
    }//GEN-LAST:event_addProductBtnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Edit_Inventory.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Edit_Inventory.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Edit_Inventory.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Edit_Inventory.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                Edit_Inventory dialog = new Edit_Inventory(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addProductBtn;
    private javax.swing.JLabel addProductheader;
    private javax.swing.JComboBox<String> categoryFilter;
    private javax.swing.JLabel errorPrice;
    private javax.swing.JLabel errorSales;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField productName;
    private javax.swing.JLabel productNameText;
    private javax.swing.JTextField productPrice;
    private javax.swing.JLabel productPriceText;
    private javax.swing.JLabel productPriceText1;
    private javax.swing.JSpinner quantity;
    private javax.swing.JTextField salesValue;
    private javax.swing.JLabel salesValueText;
    // End of variables declaration//GEN-END:variables
}
