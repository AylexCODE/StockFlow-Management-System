/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package Utilities;

import MainSystem.*;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;

/**
 *
 * @author crissa jean pagapong
 */
public class Sell_Item extends javax.swing.JDialog {
    Connection conn = new Database.Db_conn().conn();
    public boolean isItemSold = false;
    
    String prodID;
    String prodName;
    String prodCategory;
    String prodPrice;
    String prodSale;
    String prodQuantity;
    
    /**
     * Creates new form addinventory
     */
    public Sell_Item(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
    }
    
    public Sell_Item(java.awt.Frame parent, boolean modal, String ID, String prod_name, String prod_category, String prod_price, String prod_sale, String quantity) {
        super(parent, modal);
        initComponents();
        prodID = ID;
        prodName = prod_name;
        prodCategory = prod_category;
        prodPrice = prod_price.replaceAll(",", "");
        prodSale = prod_sale;
        prodQuantity = quantity;
        productName.setText(prod_name);
        productPrice.setText(prod_price);
        salesValue.setText(prod_sale);
        
        this.quantity.setValue(0);
    }
    
    public void updateItem(String prod_name, String prod_price, String prod_sale){
        DecimalFormat toDecimal = new DecimalFormat("#,###.00");
        String invalidP[] = prod_price.split("\\.");
        String invalidPS[] = prod_sale.split("\\.");

        boolean isError = false;
        if(invalidP.length > 2 || prod_price.matches("[0-9]*\\.{2,}") || prod_price.matches(".*\\.$") || prod_price.matches("[a-zA-Z]*")) {
            //new PopUp_Messages.Invalid_Add_Item(null, true, "Invalid Price!").show();
            isError = true;
        }
        if(invalidPS.length > 2 || prod_sale.matches("[0-9]*\\.{2,}") || prod_sale.matches(".*\\.$") || prod_sale.matches("[a-zA-Z]*")){
            //new PopUp_Messages.Invalid_Add_Item(null, true, "Invalid Price!").show();
            isError = true;
        }
        if(!isError && Integer.parseInt(quantity.getValue().toString()) != 0){
            Double prod_Sale = Double.parseDouble(prod_sale.replaceAll(",", ""));
            String query;
            
            int prodQ = Integer.parseInt(prodQuantity) - Integer.parseInt(quantity.getValue().toString());
            if(prodQ == 0){
                query = "DELETE FROM inventory WHERE Product_ID = '"+prodID+"';";
            }else{
                query = "UPDATE inventory SET Product_Stock = '"+prodQ+"' WHERE Product_ID = '"+prodID+"';";
            }
            try{
                PreparedStatement pst = conn.prepareStatement(query);
                pst.execute();
                
                try{
                    double amount = Double.parseDouble(toDecimal.format(prod_Sale*Integer.parseInt(quantity.getValue().toString())).replaceAll(",", ""));
                    query = "INSERT INTO logistics VALUES (null, 'Sale', '"+prodID+"','"+(Integer.parseInt(prodQuantity)-prodQ)+"', '"+prodSale.replaceAll(",", "")+"', NOW(), "+amount+");";
                    pst = conn.prepareStatement(query);
                    pst.execute();
                    
                    query = "SELECT * FROM item_info WHERE Item_Name = '"+prod_name+"';";
                    pst = conn.prepareStatement(query);
                    ResultSet rs = pst.executeQuery();
                        
                    if(!rs.next()){
                        query = "INSERT INTO item_info VALUES ('"+prodID+"','"+prod_name+"','"+prodCategory+"');";
                        pst = conn.prepareStatement(query);
                        pst.execute();
                    }
                    isItemSold = true;
                    new PopUp_Messages.Add_Product_Message(null, true, "Sold Successfully").show();
                    this.dispose();
                }catch(SQLException i){
                    System.out.println(i);
                }
            }catch(SQLException e){
                System.out.println(e);
            }
        }
        this.dispose();
    }
    
    public void resetFieldError(){
        productName.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, null, null));
        productPrice.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, null, null));
        salesValue.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, null, null));
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        addProductheader = new javax.swing.JLabel();
        productNameText = new javax.swing.JLabel();
        productName = new javax.swing.JLabel();
        productPriceText = new javax.swing.JLabel();
        productPrice = new javax.swing.JLabel();
        salesValueText = new javax.swing.JLabel();
        salesValue = new javax.swing.JLabel();
        addProductBtn = new javax.swing.JButton();
        productPriceText1 = new javax.swing.JLabel();
        quantity = new javax.swing.JSpinner();
        jSeparator1 = new javax.swing.JSeparator();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(213, 186, 72));

        addProductheader.setBackground(new java.awt.Color(61, 211, 123));
        addProductheader.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        addProductheader.setForeground(new java.awt.Color(26, 102, 159));
        addProductheader.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        addProductheader.setText("Do you really wanna sell this product?");

        productNameText.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        productNameText.setForeground(new java.awt.Color(26, 102, 159));
        productNameText.setText("Product Name:");

        productName.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        productName.setForeground(new java.awt.Color(26, 102, 159));
        productName.setText("ProductName");

        productPriceText.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        productPriceText.setForeground(new java.awt.Color(26, 102, 159));
        productPriceText.setText("Purchase Price:");

        productPrice.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        productPrice.setForeground(new java.awt.Color(26, 102, 159));
        productPrice.setText("PurchasePrice");

        salesValueText.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        salesValueText.setForeground(new java.awt.Color(26, 102, 159));
        salesValueText.setText("Sales Value:");

        salesValue.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        salesValue.setForeground(new java.awt.Color(26, 102, 159));
        salesValue.setText("SalesValue");

        addProductBtn.setBackground(new java.awt.Color(255, 255, 255));
        addProductBtn.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        addProductBtn.setForeground(new java.awt.Color(27, 65, 55));
        addProductBtn.setText("CONFIRM");
        addProductBtn.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        addProductBtn.setFocusable(false);
        addProductBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addProductBtnActionPerformed(evt);
            }
        });

        productPriceText1.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        productPriceText1.setForeground(new java.awt.Color(26, 102, 159));
        productPriceText1.setText("Quantity");

        quantity.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                quantityStateChanged(evt);
            }
        });

        jSeparator1.setBackground(new java.awt.Color(26, 102, 63));
        jSeparator1.setForeground(new java.awt.Color(26, 102, 159));
        jSeparator1.setOpaque(true);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(addProductheader, javax.swing.GroupLayout.PREFERRED_SIZE, 299, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(productPriceText1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(quantity, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(45, 45, 45)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(salesValue, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(productPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(productName, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(35, 35, 35)
                                .addComponent(addProductBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(salesValueText, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(productNameText, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(productPriceText, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(29, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(19, 19, 19)
                    .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 330, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(21, Short.MAX_VALUE)))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(addProductheader, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(productNameText)
                        .addGap(18, 18, 18)
                        .addComponent(productPriceText, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(23, 23, 23)
                        .addComponent(salesValueText)
                        .addGap(25, 25, 25)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(quantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(productPriceText1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(84, 84, 84)
                                .addComponent(salesValue))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(productName)
                                .addGap(18, 18, 18)
                                .addComponent(productPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 37, Short.MAX_VALUE)
                        .addComponent(addProductBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(19, 19, 19))))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(65, 65, 65)
                    .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(222, Short.MAX_VALUE)))
        );

        quantity.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                if(Integer.parseInt(quantity.getValue().toString())<1){
                    quantity.setValue(0);
                }
            }
        });

        quantity.setForeground(new java.awt.Color(0x619912));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 370, 290));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void addProductBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addProductBtnActionPerformed
        String prod_name = productName.getText();
        String prod_price = productPrice.getText();
        String prod_sale = salesValue.getText();
        
        resetFieldError();
        if(prod_name.isEmpty() || prod_price.isEmpty() || prod_sale.isEmpty()){
            new PopUp_Messages.Invalid_Input_Item(null, true, "Please Fill All The Fields!").show();
            if(prod_name.isEmpty()) productName.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255,65,55)));
            if(prod_price.isEmpty()) productPrice.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255,65,55)));
            if(prod_sale.isEmpty()) salesValue.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255,65,55)));
        }else{
            updateItem(prod_name, prod_price, prod_sale);
        }
    }//GEN-LAST:event_addProductBtnActionPerformed

    private void quantityStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_quantityStateChanged
        if(Integer.parseInt(quantity.getValue().toString()) >= Integer.parseInt(prodQuantity)){
            quantity.setValue(Integer.parseInt(prodQuantity));
        }
    }//GEN-LAST:event_quantityStateChanged

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Sell_Item.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Sell_Item.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Sell_Item.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Sell_Item.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                Sell_Item dialog = new Sell_Item(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addProductBtn;
    private javax.swing.JLabel addProductheader;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel productName;
    private javax.swing.JLabel productNameText;
    private javax.swing.JLabel productPrice;
    private javax.swing.JLabel productPriceText;
    private javax.swing.JLabel productPriceText1;
    private javax.swing.JSpinner quantity;
    private javax.swing.JLabel salesValue;
    private javax.swing.JLabel salesValueText;
    // End of variables declaration//GEN-END:variables
}
